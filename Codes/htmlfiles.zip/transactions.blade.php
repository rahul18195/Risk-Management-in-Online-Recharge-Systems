<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <title>My transaction</title>
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="shortcut icon" href="/walletfiles/farmzoplogoxicon.png" type="images/x-icon">	
  <link rel="stylesheet" href="/walletfiles/bootstrap.min.css">
  <script type="text/javascript" src="/walletfiles/jquery.min.js.download"></script>
  <script type="text/javascript" src="/walletfiles/bootstrap.min.js.download"></script>
  <link rel="stylesheet" type="text/css" href="/walletfiles/boot.css">
  <link rel="stylesheet" href="/walletfiles/farmerdashboard.css" type="text/css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Raleway" rel="stylesheet"> 		
  <link href="https://fonts.googleapis.com/css?family=Oswald|Roboto" rel="stylesheet">
</head>
<body id="body">
<span class="wrapper">
<header>
	<nav class="navbar navbar-static-top">
		
		
		<div class="container-fluid">
			
			<div class="navbar-header">
				
				<a class="navbar-brand" id="brand" href="#"><img src="/walletfiles/play-logo.png" width="160" height="40" alt="farmzop"></a>
				<a href="http://farmzop.com/confirm#"><img src="/walletfiles/dropdown2.png" width="40" height="30" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false" class="ddsmall navbar-right"></a>

			</div>	
			
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		
	  
					<div class="nav fllinkgroup navbar-right">
						<ul class="nav navbar-nav">
							
							<li><a href="/wallet/loadhome" id="dashboard" class="signinpopup flnlink transition radius subscription">HOME</a></li>
							<li><a href="/wallet/logout" id="milklogout" class="signinpopup flnlink transition radius">LOGOUT</a></li>
						</ul>
					</div>
     
		
			</div>	
		</div>
				
	</nav>
	</header>


		<div class="ribbon_new radius-md">
				<h4>MY TRANSCATIONS <i class="fa fa-info fanew" aria-hidden="true"></i></h4>
			</div>

<section>

	
	<div class=container">
		<div class="row">
			<table class="radius-md transition">	
				<?php echo $html?>
			</table>
		</div>
	</div>
</section>



</body>
</html>